Dost AI v2 (real voice recognition + real emotion detection)
1. Saari files GitHub repo mein upload karo (.github folder ke saath).
2. Actions > "Build APK" chalega. Ye build ke time speaker + emotion models khud download karta hai (internet wala GitHub server). 8-12 min lag sakte hain.
3. Artifacts se DostAI-apk download karo, install karo.
4. App: API key daalo > "Awaaz enroll" (3 baar 5 sec bolo) > "Voice lock" ON.
5. Upar status line mein match score aur emotion dikhta hai. Score tumhari awaaz par ~0.5+ aana chahiye; kam/zyada ho to MainActivity.kt mein SPEAKER_THRESHOLD badlo.
