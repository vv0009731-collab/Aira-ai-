package com.vineet.dost

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder

/** Raw 16 kHz mono mic audio ko ring buffer mein rakhta hai (voice + emotion analysis ke liye). */
class AudioCapture {
    private val sr = 16000
    private val ring = ShortArray(sr * 15)
    private var total = 0L
    private var rec: AudioRecord? = null
    @Volatile private var running = false

    fun start(): Boolean {
        if (running) return true
        return try {
            val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, sr,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, sr)
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return false }
            synchronized(ring) { total = 0L }
            rec = r
            r.startRecording()
            running = true
            Thread {
                val buf = ShortArray(1024)
                while (running) {
                    val n = r.read(buf, 0, buf.size)
                    if (n <= 0) { if (n < 0) break else continue }
                    synchronized(ring) {
                        for (i in 0 until n) { ring[(total % ring.size).toInt()] = buf[i]; total++ }
                    }
                }
            }.start()
            true
        } catch (e: Exception) { false }
    }

    /** Aakhri `seconds` second ki audio. */
    fun snapshot(seconds: Float): ShortArray = synchronized(ring) {
        val want = minOf((seconds * sr).toInt(), ring.size, total.toInt())
        ShortArray(want) { i -> ring[((total - want + i) % ring.size).toInt()] }
    }

    fun stop() {
        running = false
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        rec = null
    }
}
