package com.vineet.dost

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Reply(val text: String, val toolCalls: List<Pair<String, JSONObject>>)

object ClaudeClient {

    // Model yahan badal sakte ho (jaise "claude-haiku-5-5" = tez aur sasta)
    const val MODEL = "claude-sonnet-5-5"

    private const val SYSTEM = """
Tum "Dost" ho, Vineet ki personal AI dost. Hinglish (Hindi + English, Roman script) mein bilkul casual, warm aur thodi mazaakiya andaaz mein baat karti ho, jaise ek close dost. Jawab chhote rakho (1-3 vaakya) kyunki tumhari baat bolkar sunayi jaati hai. Emoji, markdown, bullet points mat use karo.
Jo user bole uska seedha, sahi jawab do. Zarurat ho to pyaar se pushback bhi karo.
Har jawab ki bilkul shuruaat mein ek tag likho: [user:mood] jahan mood in mein se ek ho: happy, excited, sad, angry, stressed, neutral. Ye user ke abhi ke mood ka tumhara andaza hai (uske shabdon aur [voice hint: ...] se, jo awaaz ki tezi/volume/speed batata hai). Tag ke baad apna jawab mood ke hisaab se do: sad ya stressed ho to naram aur care ke saath, angry ho to shaant rehkar, happy/excited ho to usi josh mein. [voice hint] ko kabhi bolkar mat padhna aur tag ke baare mein kuch mat kehna. Mood sirf andaza hai, pakka mat maan lena.
Jab user phone se kuch karwana chahe (app kholna, google search, gaana chalana, screen lock), to tool call karo aur saath mein ek chhoti friendly line bhi likho (jaise "Lo, khol diya!"). Tum screen unlock nahi kar sakti (Android security ki wajah se) - ye ho to dost ki tarah bata do ki phone ko haath se unlock karna padega.
"""

    private val TOOLS = JSONArray(
        """
[
 {"name":"open_app","description":"Phone mein koi app kholo, uske naam se.",
  "input_schema":{"type":"object","properties":{"app_name":{"type":"string"}},"required":["app_name"]}},
 {"name":"web_search","description":"Google par kuch search karo.",
  "input_schema":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
 {"name":"play_music","description":"Koi gaana ya artist chalao.",
  "input_schema":{"type":"object","properties":{"song":{"type":"string"}},"required":["song"]}},
 {"name":"lock_screen","description":"Phone ki screen lock karo.",
  "input_schema":{"type":"object","properties":{}}}
]
"""
    )

    fun chat(apiKey: String, history: JSONArray): Reply {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 400)
            .put("system", SYSTEM.trim())
            .put("tools", TOOLS)
            .put("messages", history)

        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream.bufferedReader().readText()
        if (code !in 200..299) throw RuntimeException("API error $code: $raw")

        val content = JSONObject(raw).getJSONArray("content")
        val sb = StringBuilder()
        val calls = mutableListOf<Pair<String, JSONObject>>()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            when (b.getString("type")) {
                "text" -> sb.append(b.getString("text"))
                "tool_use" -> calls.add(b.getString("name") to b.getJSONObject("input"))
            }
        }
        return Reply(sb.toString().trim(), calls)
    }
}
