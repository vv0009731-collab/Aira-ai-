package com.vineet.dost

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin

/** Kaldi-style 80-dim log-mel fbank (speaker model ke input ke liye). */
object Fbank {
    private const val SR = 16000
    private const val FL = 400
    private const val FS = 160
    private const val NFFT = 512
    private const val NM = 80

    private val window = FloatArray(FL) {
        Math.pow(0.5 - 0.5 * cos(2.0 * PI * it / (FL - 1)), 0.85).toFloat()
    }
    private val melBank: Array<FloatArray> = buildMel()

    private fun mel(f: Double) = 1127.0 * ln(1.0 + f / 700.0)

    private fun buildMel(): Array<FloatArray> {
        val low = mel(20.0)
        val high = mel(8000.0)
        val delta = (high - low) / (NM + 1)
        return Array(NM) { b ->
            val left = low + b * delta
            val center = low + (b + 1) * delta
            val right = low + (b + 2) * delta
            FloatArray(NFFT / 2 + 1) { i ->
                val m = mel(i * SR.toDouble() / NFFT)
                if (m > left && m < right) {
                    (if (m <= center) (m - left) / (center - left) else (right - m) / (right - center)).toFloat()
                } else 0f
            }
        }
    }

    fun compute(pcm: ShortArray): Array<FloatArray>? {
        if (pcm.size < FL + FS) return null
        val frames = 1 + (pcm.size - FL) / FS
        val out = Array(frames) { FloatArray(NM) }
        val re = FloatArray(NFFT)
        val im = FloatArray(NFFT)
        val w = FloatArray(FL)
        for (t in 0 until frames) {
            val off = t * FS
            var mean = 0f
            for (i in 0 until FL) { w[i] = pcm[off + i].toFloat(); mean += w[i] }
            mean /= FL
            for (i in 0 until FL) w[i] -= mean
            for (i in FL - 1 downTo 1) w[i] -= 0.97f * w[i - 1]
            w[0] -= 0.97f * w[0]
            java.util.Arrays.fill(re, 0f)
            java.util.Arrays.fill(im, 0f)
            for (i in 0 until FL) re[i] = w[i] * window[i]
            fft(re, im)
            val power = FloatArray(NFFT / 2 + 1) { re[it] * re[it] + im[it] * im[it] }
            for (b in 0 until NM) {
                var e = 0f
                val mb = melBank[b]
                for (i in power.indices) e += power[i] * mb[i]
                out[t][b] = ln(maxOf(e, 1.1920929e-7f))
            }
        }
        // cepstral mean normalization
        for (b in 0 until NM) {
            var m = 0f
            for (t in 0 until frames) m += out[t][b]
            m /= frames
            for (t in 0 until frames) out[t][b] -= m
        }
        return out
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                val half = len / 2
                for (k in 0 until half) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val vr = re[i + k + half] * cr - im[i + k + half] * ci
                    val vi = re[i + k + half] * ci + im[i + k + half] * cr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + half] = ur - vr; im[i + k + half] = ui - vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
