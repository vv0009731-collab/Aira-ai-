package com.vineet.dost

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONObject
import java.net.URLEncoder

object Actions {

    /** Tool call chalata hai aur ek chhota result string lautata hai. */
    fun run(ctx: Context, name: String, input: JSONObject): String = try {
        when (name) {
            "open_app" -> openApp(ctx, input.optString("app_name"))
            "web_search" -> webSearch(ctx, input.optString("query"))
            "play_music" -> playMusic(ctx, input.optString("song"))
            "lock_screen" -> lockScreen(ctx)
            else -> "unknown action"
        }
    } catch (e: Exception) {
        "error: ${e.message}"
    }

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val q = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "app not found: $name"
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "cannot launch $name"
        start(ctx, i)
        return "opened ${match.loadLabel(pm)}"
    }

    private fun webSearch(ctx: Context, q: String): String {
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return "searched: $q"
    }

    private fun playMusic(ctx: Context, song: String): String {
        return try {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                putExtra(android.app.SearchManager.QUERY, song)
            }
            start(ctx, i)
            "playing: $song"
        } catch (e: Exception) {
            val url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(song, "UTF-8")
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            "opened youtube search: $song"
        }
    }

    private fun lockScreen(ctx: Context): String {
        return if (LockService.lock()) {
            "locked"
        } else {
            start(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "accessibility service off - opened settings so user can enable Dost AI Screen Lock"
        }
    }
}
