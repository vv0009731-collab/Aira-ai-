package com.vineet.dost

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import kotlin.math.exp
import kotlin.math.sqrt

/** Asli ML: speaker embedding (kaun bol raha hai) + speech emotion (kaise bol raha hai). */
object Analyzer {
    private var env: OrtEnvironment? = null
    private var spk: OrtSession? = null
    private var emo: OrtSession? = null
    private var labels: List<String> = emptyList()

    @Volatile var spkReady = false
    @Volatile var emoReady = false

    fun init(ctx: Context) {
        try { env = OrtEnvironment.getEnvironment() } catch (e: Throwable) { return }
        spk = load(ctx, "speaker.onnx"); spkReady = spk != null
        emo = load(ctx, "emotion.onnx"); emoReady = emo != null
        try {
            val txt = ctx.assets.open("emotion_config.json").bufferedReader().readText()
            val m = JSONObject(txt).getJSONObject("id2label")
            labels = m.keys().asSequence().map { it.toInt() }.sorted().map { m.getString(it.toString()).lowercase() }.toList()
        } catch (e: Exception) { emoReady = false }
    }

    private fun load(ctx: Context, asset: String): OrtSession? {
        val f = File(ctx.filesDir, asset)
        return try {
            if (!f.exists() || f.length() == 0L) {
                ctx.assets.open(asset).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
            env!!.createSession(f.absolutePath, OrtSession.SessionOptions())
        } catch (e: Throwable) {
            f.delete(); null
        }
    }

    /** Speaker embedding (L2-normalized). */
    fun embedding(pcm: ShortArray): FloatArray? {
        val s = spk ?: return null
        return try {
            val fb = Fbank.compute(pcm) ?: return null
            val t = fb.size
            val flat = FloatArray(t * 80)
            for (i in 0 until t) System.arraycopy(fb[i], 0, flat, i * 80, 80)
            OnnxTensor.createTensor(env, FloatBuffer.wrap(flat), longArrayOf(1, t.toLong(), 80)).use { tensor ->
                s.run(mapOf(s.inputNames.first() to tensor)).use { r ->
                    val v = r.get(0).value
                    val e = if (v is Array<*>) v[0] as FloatArray else v as FloatArray
                    l2(e)
                }
            }
        } catch (e: Throwable) { null }
    }

    /** Emotion: (label, probability). */
    fun emotion(pcm: ShortArray): Pair<String, Float>? {
        val s = emo ?: return null
        if (labels.isEmpty() || pcm.size < 8000) return null
        return try {
            val n = minOf(pcm.size, 16000 * 10)
            val x = FloatArray(n) { pcm[pcm.size - n + it] / 32768f }
            var mean = 0f; for (v in x) mean += v; mean /= n
            var varr = 0f; for (v in x) varr += (v - mean) * (v - mean); varr /= n
            val inv = 1f / sqrt(varr + 1e-7f)
            for (i in x.indices) x[i] = (x[i] - mean) * inv
            OnnxTensor.createTensor(env, FloatBuffer.wrap(x), longArrayOf(1, n.toLong())).use { tensor ->
                s.run(mapOf(s.inputNames.first() to tensor)).use { r ->
                    val logits = (r.get(0).value as Array<*>)[0] as FloatArray
                    val mx = logits.max()
                    val ex = logits.map { exp((it - mx).toDouble()).toFloat() }
                    val sum = ex.sum()
                    val best = ex.indices.maxByOrNull { ex[it] }!!
                    labels.getOrElse(best) { "neutral" } to ex[best] / sum
                }
            }
        } catch (e: Throwable) { null }
    }

    fun cosine(a: FloatArray, b: FloatArray): Float {
        var d = 0f
        for (i in 0 until minOf(a.size, b.size)) d += a[i] * b[i]
        return d
    }

    fun l2(v: FloatArray): FloatArray {
        var n = 0f; for (x in v) n += x * x
        val s = 1f / sqrt(n + 1e-9f)
        return FloatArray(v.size) { v[it] * s }
    }

    /** Model ke label ko hamare mood mein badlo. */
    fun toMood(label: String) = when (label) {
        "angry", "disgust" -> "angry"
        "fear", "fearful" -> "stressed"
        "happy" -> "happy"
        "surprise", "surprised" -> "excited"
        "sad" -> "sad"
        else -> "neutral"
    }
}
